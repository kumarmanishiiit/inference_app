from peak import app

if __name__ == "__main__":
    app.run()

# Run with Gunicorn
# gunicorn --bind 0.0.0.0:5000 wsgi:app